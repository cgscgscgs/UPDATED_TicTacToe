﻿/* CHANGE HISTORY
 * -----------------------------------------
 * DATE         DEVELOPER        DESCRIPTION
 * ------------------------------------------
 * 2/9/2024     cgs              Initial creation of this application (GUI for CsTic project).
 *                               (This GUI was adapted from a previous version made on 2/8/2024, 
 *                               by Celina Schlecht (cgs))
 *                               Determined appropriate size for application, around 600px by 800px.
 *                               Drew tablelayoutpanel inside Form1.
 *                               Added buttons for user to click and enter X or O marker during gameplay.
 *                               Added buttons for user to manage gameplay (PLAY, restart, new player,
 *                               and end game).
 *                               Added textbox for user to enter name upon starting of game.
 *                               Added labels for all messages that display on application
 *                               (such as: welcome message, player names, win/loss/draw trackers).
 *                               Added gray color scheme, and gold and purple player colors.
 *                         
 *                               
 * 
 * 
 * 
 */


namespace TicTacToe3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.P2Draws = new System.Windows.Forms.Label();
            this.P1Draws = new System.Windows.Forms.Label();
            this.P2Losses = new System.Windows.Forms.Label();
            this.P2Wins = new System.Windows.Forms.Label();
            this.Player2Name = new System.Windows.Forms.Label();
            this.EnterNameMessage = new System.Windows.Forms.Label();
            this.NameTextbox = new System.Windows.Forms.TextBox();
            this.space9 = new System.Windows.Forms.Button();
            this.space8 = new System.Windows.Forms.Button();
            this.space7 = new System.Windows.Forms.Button();
            this.space6 = new System.Windows.Forms.Button();
            this.space5 = new System.Windows.Forms.Button();
            this.space4 = new System.Windows.Forms.Button();
            this.space3 = new System.Windows.Forms.Button();
            this.space2 = new System.Windows.Forms.Button();
            this.space1 = new System.Windows.Forms.Button();
            this.NewPlayerButton = new System.Windows.Forms.Button();
            this.RestartGameButton = new System.Windows.Forms.Button();
            this.EndGameButton = new System.Windows.Forms.Button();
            this.WelcomeMessage = new System.Windows.Forms.Label();
            this.PlayButton = new System.Windows.Forms.Button();
            this.Player1Message = new System.Windows.Forms.Label();
            this.Player2Message = new System.Windows.Forms.Label();
            this.Player1Name = new System.Windows.Forms.Label();
            this.P1Wins = new System.Windows.Forms.Label();
            this.P1Losses = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Silver;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.44371F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.11258F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.44371F));
            this.tableLayoutPanel1.Controls.Add(this.P2Draws, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.P1Draws, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.P2Losses, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.P2Wins, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.Player2Name, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.EnterNameMessage, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.NameTextbox, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.space9, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.space8, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.space7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.space6, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.space5, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.space4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.space3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.space2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.space1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.NewPlayerButton, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.RestartGameButton, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.EndGameButton, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.WelcomeMessage, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.PlayButton, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.Player1Message, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.Player2Message, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.Player1Name, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.P1Wins, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.P1Losses, 0, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.03036F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.03036F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.03036F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.105342F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.824913F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.824913F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.824913F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.824913F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.824913F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.67901F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(553, 763);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // P2Draws
            // 
            this.P2Draws.AutoSize = true;
            this.P2Draws.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P2Draws.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.P2Draws.Location = new System.Drawing.Point(370, 632);
            this.P2Draws.Name = "P2Draws";
            this.P2Draws.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.P2Draws.Size = new System.Drawing.Size(180, 44);
            this.P2Draws.TabIndex = 43;
            this.P2Draws.Text = "Draws:";
            // 
            // P1Draws
            // 
            this.P1Draws.AutoSize = true;
            this.P1Draws.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P1Draws.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.P1Draws.Location = new System.Drawing.Point(3, 632);
            this.P1Draws.Name = "P1Draws";
            this.P1Draws.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.P1Draws.Size = new System.Drawing.Size(178, 44);
            this.P1Draws.TabIndex = 41;
            this.P1Draws.Text = "Draws:";
            // 
            // P2Losses
            // 
            this.P2Losses.AutoSize = true;
            this.P2Losses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P2Losses.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.P2Losses.Location = new System.Drawing.Point(370, 588);
            this.P2Losses.Name = "P2Losses";
            this.P2Losses.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.P2Losses.Size = new System.Drawing.Size(180, 44);
            this.P2Losses.TabIndex = 39;
            this.P2Losses.Text = "Losses:";
            // 
            // P2Wins
            // 
            this.P2Wins.AutoSize = true;
            this.P2Wins.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P2Wins.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.P2Wins.Location = new System.Drawing.Point(370, 544);
            this.P2Wins.Name = "P2Wins";
            this.P2Wins.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.P2Wins.Size = new System.Drawing.Size(180, 44);
            this.P2Wins.TabIndex = 36;
            this.P2Wins.Text = "Wins:";
            // 
            // Player2Name
            // 
            this.Player2Name.AutoSize = true;
            this.Player2Name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player2Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Player2Name.Location = new System.Drawing.Point(370, 500);
            this.Player2Name.Name = "Player2Name";
            this.Player2Name.Size = new System.Drawing.Size(180, 44);
            this.Player2Name.TabIndex = 33;
            this.Player2Name.Text = "\"\"";
            this.Player2Name.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // EnterNameMessage
            // 
            this.EnterNameMessage.AutoSize = true;
            this.EnterNameMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EnterNameMessage.Location = new System.Drawing.Point(184, 500);
            this.EnterNameMessage.Margin = new System.Windows.Forms.Padding(0);
            this.EnterNameMessage.Name = "EnterNameMessage";
            this.EnterNameMessage.Size = new System.Drawing.Size(183, 44);
            this.EnterNameMessage.TabIndex = 28;
            this.EnterNameMessage.Text = "Please enter name here:";
            this.EnterNameMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NameTextbox
            // 
            this.NameTextbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NameTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.NameTextbox.Location = new System.Drawing.Point(187, 547);
            this.NameTextbox.Name = "NameTextbox";
            this.NameTextbox.Size = new System.Drawing.Size(177, 30);
            this.NameTextbox.TabIndex = 21;
            // 
            // space9
            // 
            this.space9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space9.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space9.ForeColor = System.Drawing.Color.Violet;
            this.space9.Location = new System.Drawing.Point(370, 261);
            this.space9.Name = "space9";
            this.space9.Size = new System.Drawing.Size(180, 123);
            this.space9.TabIndex = 8;
            this.space9.Text = "O";
            this.space9.UseVisualStyleBackColor = false;
            // 
            // space8
            // 
            this.space8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space8.ForeColor = System.Drawing.Color.Gold;
            this.space8.Location = new System.Drawing.Point(187, 261);
            this.space8.Name = "space8";
            this.space8.Size = new System.Drawing.Size(177, 123);
            this.space8.TabIndex = 7;
            this.space8.Text = "X";
            this.space8.UseVisualStyleBackColor = false;
            // 
            // space7
            // 
            this.space7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.space7.ForeColor = System.Drawing.Color.Gold;
            this.space7.Location = new System.Drawing.Point(3, 261);
            this.space7.Name = "space7";
            this.space7.Size = new System.Drawing.Size(178, 123);
            this.space7.TabIndex = 6;
            this.space7.Text = "X";
            this.space7.UseVisualStyleBackColor = false;
            // 
            // space6
            // 
            this.space6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space6.ForeColor = System.Drawing.Color.Violet;
            this.space6.Location = new System.Drawing.Point(370, 132);
            this.space6.Name = "space6";
            this.space6.Size = new System.Drawing.Size(180, 123);
            this.space6.TabIndex = 5;
            this.space6.Text = "O";
            this.space6.UseVisualStyleBackColor = false;
            // 
            // space5
            // 
            this.space5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space5.ForeColor = System.Drawing.Color.Violet;
            this.space5.Location = new System.Drawing.Point(187, 132);
            this.space5.Name = "space5";
            this.space5.Size = new System.Drawing.Size(177, 123);
            this.space5.TabIndex = 4;
            this.space5.Text = "O";
            this.space5.UseVisualStyleBackColor = false;
            // 
            // space4
            // 
            this.space4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space4.ForeColor = System.Drawing.Color.Violet;
            this.space4.Location = new System.Drawing.Point(3, 132);
            this.space4.Name = "space4";
            this.space4.Size = new System.Drawing.Size(178, 123);
            this.space4.TabIndex = 3;
            this.space4.Text = "O";
            this.space4.UseVisualStyleBackColor = false;
            // 
            // space3
            // 
            this.space3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space3.ForeColor = System.Drawing.Color.Gold;
            this.space3.Location = new System.Drawing.Point(370, 3);
            this.space3.Name = "space3";
            this.space3.Size = new System.Drawing.Size(180, 123);
            this.space3.TabIndex = 2;
            this.space3.Text = "X";
            this.space3.UseVisualStyleBackColor = false;
            // 
            // space2
            // 
            this.space2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space2.ForeColor = System.Drawing.Color.Violet;
            this.space2.Location = new System.Drawing.Point(187, 3);
            this.space2.Name = "space2";
            this.space2.Size = new System.Drawing.Size(177, 123);
            this.space2.TabIndex = 1;
            this.space2.Text = "O";
            this.space2.UseVisualStyleBackColor = false;
            // 
            // space1
            // 
            this.space1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.space1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.space1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold);
            this.space1.ForeColor = System.Drawing.Color.Gold;
            this.space1.Location = new System.Drawing.Point(3, 3);
            this.space1.Name = "space1";
            this.space1.Size = new System.Drawing.Size(178, 123);
            this.space1.TabIndex = 0;
            this.space1.Text = "X";
            this.space1.UseVisualStyleBackColor = false;
            // 
            // NewPlayerButton
            // 
            this.NewPlayerButton.BackColor = System.Drawing.Color.LightGray;
            this.NewPlayerButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NewPlayerButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NewPlayerButton.Font = new System.Drawing.Font("Cascadia Code", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPlayerButton.Location = new System.Drawing.Point(5, 681);
            this.NewPlayerButton.Margin = new System.Windows.Forms.Padding(5);
            this.NewPlayerButton.Name = "NewPlayerButton";
            this.NewPlayerButton.Padding = new System.Windows.Forms.Padding(10);
            this.NewPlayerButton.Size = new System.Drawing.Size(174, 77);
            this.NewPlayerButton.TabIndex = 10;
            this.NewPlayerButton.Text = "New Player";
            this.NewPlayerButton.UseVisualStyleBackColor = false;
            // 
            // RestartGameButton
            // 
            this.RestartGameButton.BackColor = System.Drawing.Color.LightGray;
            this.RestartGameButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RestartGameButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RestartGameButton.Font = new System.Drawing.Font("Cascadia Code", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RestartGameButton.Location = new System.Drawing.Point(189, 681);
            this.RestartGameButton.Margin = new System.Windows.Forms.Padding(5);
            this.RestartGameButton.Name = "RestartGameButton";
            this.RestartGameButton.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.RestartGameButton.Size = new System.Drawing.Size(173, 77);
            this.RestartGameButton.TabIndex = 11;
            this.RestartGameButton.Text = "Restart Game";
            this.RestartGameButton.UseVisualStyleBackColor = false;
            // 
            // EndGameButton
            // 
            this.EndGameButton.BackColor = System.Drawing.Color.LightGray;
            this.EndGameButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EndGameButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EndGameButton.Font = new System.Drawing.Font("Cascadia Code", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EndGameButton.Location = new System.Drawing.Point(372, 681);
            this.EndGameButton.Margin = new System.Windows.Forms.Padding(5);
            this.EndGameButton.Name = "EndGameButton";
            this.EndGameButton.Padding = new System.Windows.Forms.Padding(10);
            this.EndGameButton.Size = new System.Drawing.Size(176, 77);
            this.EndGameButton.TabIndex = 12;
            this.EndGameButton.Text = "End Game";
            this.EndGameButton.UseVisualStyleBackColor = false;
            // 
            // WelcomeMessage
            // 
            this.WelcomeMessage.AutoSize = true;
            this.WelcomeMessage.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel1.SetColumnSpan(this.WelcomeMessage, 3);
            this.WelcomeMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WelcomeMessage.Font = new System.Drawing.Font("Cascadia Code", 14F, System.Drawing.FontStyle.Bold);
            this.WelcomeMessage.Location = new System.Drawing.Point(3, 387);
            this.WelcomeMessage.Name = "WelcomeMessage";
            this.WelcomeMessage.Size = new System.Drawing.Size(547, 69);
            this.WelcomeMessage.TabIndex = 13;
            this.WelcomeMessage.Text = "Welcome to TIC TAC TOE";
            this.WelcomeMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PlayButton
            // 
            this.PlayButton.BackColor = System.Drawing.Color.LightGray;
            this.PlayButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PlayButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PlayButton.Font = new System.Drawing.Font("Cascadia Code", 10F);
            this.PlayButton.Location = new System.Drawing.Point(187, 591);
            this.PlayButton.Name = "PlayButton";
            this.PlayButton.Size = new System.Drawing.Size(177, 38);
            this.PlayButton.TabIndex = 15;
            this.PlayButton.Text = "PLAY";
            this.PlayButton.UseVisualStyleBackColor = false;
            // 
            // Player1Message
            // 
            this.Player1Message.AutoSize = true;
            this.Player1Message.BackColor = System.Drawing.Color.Violet;
            this.Player1Message.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player1Message.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Player1Message.Location = new System.Drawing.Point(10, 461);
            this.Player1Message.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.Player1Message.Name = "Player1Message";
            this.Player1Message.Size = new System.Drawing.Size(164, 34);
            this.Player1Message.TabIndex = 29;
            this.Player1Message.Text = "Player 1";
            this.Player1Message.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Player2Message
            // 
            this.Player2Message.AutoSize = true;
            this.Player2Message.BackColor = System.Drawing.Color.Gold;
            this.Player2Message.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player2Message.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Player2Message.Location = new System.Drawing.Point(377, 461);
            this.Player2Message.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.Player2Message.Name = "Player2Message";
            this.Player2Message.Size = new System.Drawing.Size(166, 34);
            this.Player2Message.TabIndex = 30;
            this.Player2Message.Text = "Player 2";
            this.Player2Message.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Player1Name
            // 
            this.Player1Name.AutoSize = true;
            this.Player1Name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player1Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Player1Name.Location = new System.Drawing.Point(3, 500);
            this.Player1Name.Name = "Player1Name";
            this.Player1Name.Size = new System.Drawing.Size(178, 44);
            this.Player1Name.TabIndex = 31;
            this.Player1Name.Text = "\"\"";
            this.Player1Name.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // P1Wins
            // 
            this.P1Wins.AutoSize = true;
            this.P1Wins.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P1Wins.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.P1Wins.Location = new System.Drawing.Point(3, 544);
            this.P1Wins.Name = "P1Wins";
            this.P1Wins.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.P1Wins.Size = new System.Drawing.Size(178, 44);
            this.P1Wins.TabIndex = 34;
            this.P1Wins.Text = "Wins:";
            // 
            // P1Losses
            // 
            this.P1Losses.AutoSize = true;
            this.P1Losses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P1Losses.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.P1Losses.Location = new System.Drawing.Point(3, 588);
            this.P1Losses.Name = "P1Losses";
            this.P1Losses.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.P1Losses.Size = new System.Drawing.Size(178, 44);
            this.P1Losses.TabIndex = 37;
            this.P1Losses.Text = "Losses:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(553, 763);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "TicTacToe";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button space1;
        private System.Windows.Forms.Button space9;
        private System.Windows.Forms.Button space8;
        private System.Windows.Forms.Button space7;
        private System.Windows.Forms.Button space6;
        private System.Windows.Forms.Button space5;
        private System.Windows.Forms.Button space4;
        private System.Windows.Forms.Button space3;
        private System.Windows.Forms.Button space2;
        private System.Windows.Forms.Button NewPlayerButton;
        private System.Windows.Forms.Button RestartGameButton;
        private System.Windows.Forms.Button EndGameButton;
        private System.Windows.Forms.Label WelcomeMessage;
        private System.Windows.Forms.Button PlayButton;
        private System.Windows.Forms.TextBox NameTextbox;
        private System.Windows.Forms.Label EnterNameMessage;
        private System.Windows.Forms.Label Player1Message;
        private System.Windows.Forms.Label Player2Message;
        private System.Windows.Forms.Label Player1Name;
        private System.Windows.Forms.Label Player2Name;
        private System.Windows.Forms.Label P2Wins;
        private System.Windows.Forms.Label P1Wins;
        private System.Windows.Forms.Label P1Losses;
        private System.Windows.Forms.Label P2Losses;
        private System.Windows.Forms.Label P2Draws;
        private System.Windows.Forms.Label P1Draws;
    }
}

